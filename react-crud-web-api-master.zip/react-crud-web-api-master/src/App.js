import React, { Component } from "react";
import { Routes, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import AddTutorial from "./components/add-tutorial.component";
import Tutorial from "./components/tutorial.component";
import TutorialsList from "./components/tutorials-list.component";
import Login from "./components/login.component";
import Create from "./components/create.component";

class App extends Component {

  constructor(props) {
    super(props);
    this.forceUpdateHandler = this.forceUpdateHandler.bind(this);
    this.state = {
      login:false,
      username:""
    };

    if(localStorage.getItem('login')!=null){
      console.log("loginn...")
      this.state.login=true;
      this.state.username=localStorage.getItem('username');
    }
  }

  forceUpdateHandler(){
    console.log("handleClick1");
    if(localStorage.getItem('login')!=null){
      this.setState({login: true,username:localStorage.getItem('username')});
    }
  };

  handleClick = () => {
    this.setState({login: false,username:''});
    if(localStorage.getItem('login')!=null){
      localStorage.removeItem('login');
      localStorage.removeItem('username');
    }
  };

  render() {
    return (
      <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          <Link to={"/tutorials"} className="navbar-brand">
            Demo
          </Link>
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/tutorials"} className="nav-link">
                Tutorials
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/add"} className="nav-link">
                Add
              </Link>
            </li>
          </div>
          <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
            <ul class="navbar-nav ml-auto">
              { this.state.login ? 
              <li className="nav-item">
                <Link to={"/tutorials"} className="nav-link">
                <span onClick={this.handleClick}>{this.state.username}   Logout</span>
                </Link>
              </li>
             :
             <li className="nav-item">
                <Link to={"/Login"} className="nav-link">
                  Login
                </Link>
              </li>
             
              }
               </ul>
          </div>
        </nav>

        <div className="container mt-3">
          <Routes>
            <Route path="/" element={<TutorialsList/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/create" element={<Create/>} />
            <Route path="/tutorials" element={<TutorialsList/>} />
            <Route path="/add" element={<AddTutorial/>} />
            <Route path="/tutorials/:id" element={<Tutorial/>} />
          </Routes>
        </div>
      </div>
    );
  }
}

export default App;
